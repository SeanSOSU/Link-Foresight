﻿chrome.runtime.onConnect.addListener(function (port) {
    console.assert(port.name == "Link Foresight");

    port.onMessage.addListener(function (message) {
        readURL(port, message);
    });
});

function readURL(port, message) {
    $.ajax({
        url: message.url,
        type: "GET",
        dataType: "html",
        error: function (textStatus) {
            console.log(textStatus);
        },
        success: function (data, textStatus) {
            console.log(textStatus);

            var title = $(data).filter("title").text();
            port.postMessage({ Success: true, Title: title });
        }
    });
}

function parseInfo(data, textStatus) {
    console.log("data.title");
    console.log("Test 1 Success");
}

/*function isYoutubeURL(url) {
    var regex = /^(?:https?:\/\/)?(?:m\.|www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/;
    
    return url.match(regex) ?
}*/